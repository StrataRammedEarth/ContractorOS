import type { Assembly, CommercialRules, LibraryData, Material, Resource } from "./types";

const material = (
  code: string,
  description: string,
  unit: string,
  unitRate: number,
  supplier: string,
  source: string,
): Material => ({ code, description, unit, unitRate, supplier, confidence: "Locked", source, active: true });

export const materials: Material[] = [
  material("BE1WH813", "CTM Coral White Toilet Suite", "ea", 929.9, "CTM", "PLUMB_KB_v1.0_LOCKED-1"),
  material("29892", "Angle Valve", "ea", 65.21, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("34675", "Pan Connector Jollyflex 350mm", "ea", 190.43, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("RCM-WC-001", "White Sikaflex 310ml", "tube", 129.9, "Project Architect", "PLUMB_KB_v1.0_LOCKED-1"),
  material("BE1WH9102", "Basin Starna White", "ea", 649.9, "CTM", "PLUMB_KB_v1.0_LOCKED-1"),
  material("AfriCamps", "Basin Mixer", "ea", 489.63, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("32232", "Basin Waste Pop-up Unslotted", "ea", 141.04, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("35486", "Bottle Trap Universal", "ea", 216.52, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("185", "Braided Hose 350mm", "ea", 42.61, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("RCM-BSN-001", "Mould Resistant Silicone", "tube", 89.9, "Project Architect", "PLUMB_KB_v1.0_LOCKED-1"),
  material("34147", "Shower Mixer Classic", "ea", 355.65, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("30728", "Konex Female Elbow shower arm", "ea", 33.72, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("30730", "Konex Female Elbow mixer", "ea", 29.17, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("7321", "Shower Arm 350mm Round", "ea", 139, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("7316", "Shower Rose 200mm Stainless Steel", "ea", 477.39, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("15501", "Shower Waste Drain Stainless Steel", "ea", 328.38, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("1924", "PVC 40-50mm Adaptor", "ea", 8.78, "Africamps procurement", "PLUMB_KB_v1.0_LOCKED-1"),
  material("CT8006", "Glass Shower Door Chrome", "ea", 3559, "CTM", "PLUMB_KB_v1.0_LOCKED-1"),
  material("RCM-SHWD-PRATLEY", "Pratley Steel Quick Set", "ea", 74.9, "Project Architect", "PLUMB_KB_v1.0_LOCKED-1"),
  material("RCM-SHWD-EPOXY", "Epoxy Syringe", "ea", 12.9, "Project Architect", "PLUMB_KB_v1.0_LOCKED-1"),
  material("DCK-S01", "SA Pine Decking Plank 21x108x4800", "ea", 169.5, "Africamps source truth", "VAL-004_Source_Truth_Archive"),
  material("DCK-S02", "Chipboard Screw 5x60mm", "ea", 0.35, "Africamps source truth", "VAL-004_Source_Truth_Archive"),
  material("DCK-B01", "Treated Pine Beam 38x114mm", "ea", 127, "Africamps source truth", "VAL-004_Source_Truth_Archive"),
  material("DCK-B02", "Treated Pine Beam 50x152mm", "ea", 291, "Africamps source truth", "VAL-004_Source_Truth_Archive"),
  material("DCK-B03", "M12 Threaded Rod cut length", "ea", 2.95, "Africamps source truth", "VAL-004_Source_Truth_Archive"),
  material("DCK-B04", "M12 Washer 24mm galvanised", "ea", 0.35, "Africamps source truth", "VAL-004_Source_Truth_Archive"),
  material("DCK-B05", "M12 Nut galvanised", "ea", 1.07, "Africamps source truth", "VAL-004_Source_Truth_Archive"),
];

export const resources: Resource[] = [
  { code: "PLM-LAB-001", name: "Plumbing Assistant", unit: "hour", rate: 32.5, confidence: "Validated", source: "PLUMB_Productivity_Library_v1" },
  { code: "PLM-LAB-002", name: "Supervising Plumber", unit: "day", rate: 600, confidence: "Validated", source: "14_Plumbing_Resource_Library-1" },
  { code: "DCK-CREW-001", name: "Carpenter and Labourer Crew", unit: "day", rate: 1000, confidence: "Validated", source: "ARCH-UPDATE-035" },
  { code: "BRK-CREW-001", name: "Masonry Crew", unit: "hour", rate: 200, confidence: "Assumption", source: "MASONRY_KB_v1" },
];

const fixtureAssembly = (
  code: string,
  name: string,
  recipe: Assembly["recipe"],
  hours: number,
): Assembly => ({
  code,
  name,
  trade: "Plumbing",
  unit: "ea",
  baseQuantity: 1,
  confidence: "Validated",
  status: "Active",
  source: "PLUMB_KB_v1.0_LOCKED-1",
  recipe,
  labour: [{ resourceCode: "PLM-LAB-001", quantity: hours, activity: `${name} installation` }],
});

export const assemblies: Assembly[] = [
  {
    code: "PLB-000", name: "Standard Africamps Plumbing Package", trade: "Plumbing", unit: "structure",
    baseQuantity: 1, basePrimeCost: 6731.01, baseMaterialCost: 6171.01, baseLabourCost: 560,
    confidence: "Locked", status: "Active", source: "Assembly_Scaling_Rules_v1.2",
    notes: "Locked benchmark container. Detailed child selection is available through fixture assemblies.",
    recipe: [], labour: [],
  },
  {
    code: "PLB-001", name: "Cold Water Supply", trade: "Plumbing", unit: "pts",
    baseQuantity: 4, basePrimeCost: 2101.77, baseMaterialCost: 1841.77, baseLabourCost: 260,
    confidence: "Locked", status: "Active", source: "Assembly_Scaling_Rules_v1.2", recipe: [], labour: [],
  },
  {
    code: "PLB-002", name: "Hot Water Supply", trade: "Plumbing", unit: "pts",
    baseQuantity: 3, basePrimeCost: 1749.47, baseMaterialCost: 1489.47, baseLabourCost: 260,
    confidence: "Locked", status: "Active", source: "Assembly_Scaling_Rules_v1.2", recipe: [], labour: [],
  },
  fixtureAssembly("DEP-WC-001", "Toilet Assembly", [
    { materialCode: "BE1WH813", quantity: 1 }, { materialCode: "29892", quantity: 1 },
    { materialCode: "34675", quantity: 1 }, { materialCode: "RCM-WC-001", quantity: 0.3 },
  ], 1.83),
  fixtureAssembly("DEP-BSN-001", "Basin Assembly", [
    { materialCode: "BE1WH9102", quantity: 1 }, { materialCode: "AfriCamps", quantity: 1 },
    { materialCode: "32232", quantity: 1 }, { materialCode: "35486", quantity: 1 },
    { materialCode: "29892", quantity: 2 }, { materialCode: "185", quantity: 2 },
    { materialCode: "RCM-BSN-001", quantity: 0.3 },
  ], 1.5),
  fixtureAssembly("DEP-SHW-001", "Shower Assembly", [
    { materialCode: "34147", quantity: 1 }, { materialCode: "30728", quantity: 1 },
    { materialCode: "30730", quantity: 2 }, { materialCode: "7321", quantity: 1 },
    { materialCode: "7316", quantity: 1 }, { materialCode: "15501", quantity: 1 },
    { materialCode: "1924", quantity: 1 },
  ], 1.17),
  fixtureAssembly("DEP-SHWD-001", "Shower Door Assembly", [
    { materialCode: "CT8006", quantity: 1 }, { materialCode: "RCM-SHWD-PRATLEY", quantity: 1 },
    { materialCode: "RCM-SHWD-EPOXY", quantity: 1 },
  ], 1),
  {
    code: "PLB-004", name: "Testing and Commissioning", trade: "Plumbing", unit: "allowance",
    baseQuantity: 1, basePrimeCost: 300, baseMaterialCost: 0, baseLabourCost: 300,
    confidence: "Validated", status: "Active", source: "15_Plumbing_Resource_Consumption_Mapping", recipe: [], labour: [],
  },
  {
    code: "DCK-001", name: "Deck Construction", trade: "Decking", unit: "m2",
    baseQuantity: 25, basePrimeCost: 12667.25, baseMaterialCost: 11667.25, baseLabourCost: 1000,
    confidence: "Locked", status: "Active", source: "Assembly_Scaling_Rules_v1.2 / ARCH-UPDATE-035",
    recipe: [
      { materialCode: "DCK-S01", quantity: 46.75 }, { materialCode: "DCK-S02", quantity: 934.75 },
      { materialCode: "DCK-B01", quantity: 16.3 }, { materialCode: "DCK-B02", quantity: 4.35 },
      { materialCode: "DCK-B03", quantity: 14.12 }, { materialCode: "DCK-B04", quantity: 28.25 },
      { materialCode: "DCK-B05", quantity: 28.25 },
    ],
    labour: [{ resourceCode: "DCK-CREW-001", quantity: 1, activity: "Deck construction" }],
  },
  {
    code: "BAL-001", name: "Steel Cable Balustrade", trade: "Decking", unit: "m",
    baseQuantity: 15, basePrimeCost: 4956.6, confidence: "Provisional", status: "Active",
    source: "Assembly_Scaling_Rules_v1.2", notes: "Labour placeholder pending first completed balustrade project.", recipe: [], labour: [],
  },
  ...[
    ["BRK-001", "Half Brick Wall (face 1 side)", 417.7],
    ["BRK-002", "One Brick Wall (face 1 side)", 779.9],
    ["BRK-003", "One and Half Brick Wall", 1144.4],
    ["BRK-004", "Half Brick Wall (face 2 sides)", 441.7],
    ["BRK-005", "Half Brick Hollow Wall Skin", 441.7],
    ["BRK-FACE", "Face Brick Premium", 199.3],
  ].map(([code, name, cost]) => ({
    code: String(code), name: String(name), trade: "Masonry" as const, unit: "m2", baseQuantity: 1,
    basePrimeCost: Number(cost), confidence: "Assumption" as const, status: "Active" as const,
    source: "MASONRY_KB_v1 / Assembly_Scaling_Rules_v1.2",
    notes: "Pending South African contractor validation.", recipe: [], labour: [],
  })),
];

export const rules: CommercialRules = {
  wastePct: 5,
  riskPct: 5,
  contingencyPct: 10,
  marginPct: 25,
  vatPct: 15,
};

export const seedLibrary: LibraryData = { materials, resources, assemblies, rules };

export type Confidence = "Locked" | "Validated" | "Provisional" | "Assumption" | "Unknown";
export type Trade = "Plumbing" | "Decking" | "Masonry" | "Logistics";

export interface Material {
  code: string;
  description: string;
  unit: string;
  unitRate: number | null;
  supplier: string;
  supplierCode?: string;
  confidence: Confidence;
  source: string;
  active: boolean;
}

export interface Resource {
  code: string;
  name: string;
  unit: "hour" | "day";
  rate: number;
  confidence: Confidence;
  source: string;
}

export interface RecipeItem {
  materialCode: string;
  quantity: number;
}

export interface LabourItem {
  resourceCode: string;
  quantity: number;
  activity: string;
}

export interface Assembly {
  code: string;
  name: string;
  trade: Trade;
  unit: string;
  baseQuantity: number;
  basePrimeCost?: number;
  baseMaterialCost?: number;
  baseLabourCost?: number;
  confidence: Confidence;
  status: "Active" | "Archived";
  source: string;
  notes?: string;
  recipe: RecipeItem[];
  labour: LabourItem[];
}

export interface LibraryData {
  materials: Material[];
  resources: Resource[];
  assemblies: Assembly[];
  rules: CommercialRules;
}

export interface CommercialRules {
  wastePct: number;
  riskPct: number;
  contingencyPct: number;
  marginPct: number;
  vatPct: number;
}

export interface ScopeItem {
  assemblyCode: string;
  quantity: number;
}

export interface EstimateInput {
  projectName: string;
  clientName: string;
  reference: string;
  vatEnabled: boolean;
  scope: ScopeItem[];
}

export interface EstimateLine {
  code: string;
  description: string;
  trade: Trade;
  quantity: number;
  unit: string;
  material: number;
  labour: number;
  prime: number;
  confidence: Confidence;
  warnings: string[];
}

export interface BuyLine {
  materialCode: string;
  description: string;
  supplier: string;
  unit: string;
  quantity: number;
  unitRate: number;
  total: number;
  confidence: Confidence;
}

export interface BuildLine {
  assemblyCode: string;
  activity: string;
  resource: string;
  quantity: number;
  unit: string;
  rate: number;
  total: number;
  confidence: Confidence;
}

export interface EstimateSnapshot {
  id: string;
  version: number;
  createdAt: string;
  input: EstimateInput;
  lines: EstimateLine[];
  buy: BuyLine[];
  build: BuildLine[];
  rules: CommercialRules;
  totals: {
    material: number;
    labour: number;
    prime: number;
    waste: number;
    direct: number;
    risk: number;
    riskAdjusted: number;
    contingency: number;
    cost: number;
    margin: number;
    sellExVat: number;
    vat: number;
    sellIncVat: number;
  };
  warnings: string[];
}

export interface ActualRecord {
  estimateId: string;
  actualMaterial: number;
  actualLabour: number;
  actualFinalValue: number;
  notes: string;
  createdAt: string;
}

export interface ImportIssue {
  row: number;
  severity: "error" | "warning";
  code: "duplicate" | "conflict" | "invalid-unit" | "missing-price" | "encoding" | "superseded";
  message: string;
}

import { describe, expect, it } from "vitest";
import { calculateEstimate, validateForFinal } from "./engine";
import { seedLibrary } from "./seed";

const input = (code: string, quantity: number, vatEnabled = false) => ({
  projectName: "Test",
  clientName: "Test Client",
  reference: "TEST-001",
  vatEnabled,
  scope: [{ assemblyCode: code, quantity }],
});

describe("reliable estimating core", () => {
  it("matches the locked PLB-000 prime benchmark", () => {
    expect(calculateEstimate(input("PLB-000", 1), seedLibrary).totals.prime).toBe(6731.01);
  });

  it("matches the corrected DCK-001 25m2 prime benchmark", () => {
    expect(calculateEstimate(input("DCK-001", 25), seedLibrary).totals.prime).toBe(12667.25);
  });

  it("matches masonry benchmarks and flags assumptions", () => {
    const estimate = calculateEstimate(input("BRK-001", 1), seedLibrary);
    expect(estimate.totals.prime).toBe(417.7);
    expect(estimate.warnings.some((warning) => warning.includes("assumption grade"))).toBe(true);
  });

  it("applies commercial rules in documented order", () => {
    const totals = calculateEstimate(input("DCK-001", 25), seedLibrary).totals;
    expect(totals.waste).toBe(583.36);
    expect(totals.direct).toBe(13250.61);
    expect(totals.risk).toBe(662.53);
    expect(totals.riskAdjusted).toBe(13913.14);
    expect(totals.contingency).toBe(1391.31);
    expect(totals.margin).toBe(3826.11);
    expect(totals.sellExVat).toBe(19130.56);
  });

  it("applies optional VAT after the sell total", () => {
    const totals = calculateEstimate(input("DCK-001", 25, true), seedLibrary).totals;
    expect(totals.vat).toBe(2869.58);
    expect(totals.sellIncVat).toBe(22000.14);
  });

  it("blocks empty estimates", () => {
    const estimate = calculateEstimate({ ...input("DCK-001", 0), scope: [] }, seedLibrary);
    expect(validateForFinal(estimate).valid).toBe(false);
  });

  it("snapshots rules independently from later changes", () => {
    const estimate = calculateEstimate(input("DCK-001", 25), seedLibrary);
    const changed = structuredClone(seedLibrary);
    changed.rules.marginPct = 99;
    expect(estimate.rules.marginPct).toBe(25);
  });
});

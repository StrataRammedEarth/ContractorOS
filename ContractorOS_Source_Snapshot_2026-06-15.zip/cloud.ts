import { seedLibrary } from "./seed";
import { supabase } from "./supabase";
import type { ActualRecord, EstimateSnapshot, LibraryData } from "./types";

const requireClient = () => {
  if (!supabase) throw new Error("Supabase is not configured.");
  return supabase;
};

export async function getOrganizationId() {
  const client = requireClient();
  const { data: memberships } = await client.from("organization_members").select("organization_id").limit(1);
  if (memberships?.[0]?.organization_id) return memberships[0].organization_id as string;
  const { data, error } = await client.rpc("bootstrap_owner_organization", { org_name: "ContractorOS" });
  if (error) throw error;
  return data as string;
}

export async function loadCloudLibrary(orgId: string): Promise<LibraryData> {
  const client = requireClient();
  const { data, error } = await client.from("library_records").select("record_type,code,data").eq("organization_id", orgId).eq("status", "active");
  if (error) throw error;
  if (!data?.length) {
    await saveCloudLibrary(orgId, seedLibrary);
    return structuredClone(seedLibrary);
  }
  const records = data as { record_type: string; code: string; data: unknown }[];
  return {
    materials: records.filter((item) => item.record_type === "material").map((item) => item.data) as LibraryData["materials"],
    resources: records.filter((item) => item.record_type === "resource").map((item) => item.data) as LibraryData["resources"],
    assemblies: records.filter((item) => item.record_type === "assembly").map((item) => item.data) as LibraryData["assemblies"],
    rules: (records.find((item) => item.record_type === "commercial_rule")?.data ?? seedLibrary.rules) as LibraryData["rules"],
  };
}

export async function saveCloudLibrary(orgId: string, library: LibraryData) {
  const client = requireClient();
  const rows = [
    ...library.materials.map((data) => ({ record_type: "material", code: data.code, confidence: data.confidence, source: data.source, data })),
    ...library.resources.map((data) => ({ record_type: "resource", code: data.code, confidence: data.confidence, source: data.source, data })),
    ...library.assemblies.map((data) => ({ record_type: "assembly", code: data.code, confidence: data.confidence, source: data.source, data })),
    { record_type: "commercial_rule", code: "COMMERCIAL-RULES", confidence: "Assumption", source: "07_Commercial_Rules.csv", data: library.rules },
  ].map((row) => ({ ...row, organization_id: orgId, status: "active" }));
  const { error } = await client.from("library_records").upsert(rows, { onConflict: "organization_id,record_type,code,status" });
  if (error) throw error;
}

export async function loadCloudEstimates(orgId: string): Promise<EstimateSnapshot[]> {
  const { data, error } = await requireClient().from("estimate_versions").select("snapshot").eq("organization_id", orgId).order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []).map((item) => item.snapshot as EstimateSnapshot);
}

export async function saveCloudEstimate(orgId: string, snapshot: EstimateSnapshot, existing: EstimateSnapshot[]) {
  const version = existing.filter((item) => item.input.reference === snapshot.input.reference).length + 1;
  const saved = { ...snapshot, version };
  const { error } = await requireClient().from("estimate_versions").insert({
    id: saved.id, organization_id: orgId, reference: saved.input.reference, version, snapshot: saved, status: "final",
  });
  if (error) throw error;
  return saved;
}

export async function loadCloudActuals(orgId: string): Promise<ActualRecord[]> {
  const { data, error } = await requireClient().from("actual_records").select("estimate_version_id,actual_material,actual_labour,actual_final_value,notes,created_at").eq("organization_id", orgId).order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []).map((item) => ({
    estimateId: item.estimate_version_id,
    actualMaterial: Number(item.actual_material),
    actualLabour: Number(item.actual_labour),
    actualFinalValue: Number(item.actual_final_value),
    notes: item.notes,
    createdAt: item.created_at,
  }));
}

export async function saveCloudActual(orgId: string, actual: ActualRecord) {
  const { error } = await requireClient().from("actual_records").insert({
    organization_id: orgId,
    estimate_version_id: actual.estimateId,
    actual_material: actual.actualMaterial,
    actual_labour: actual.actualLabour,
    actual_final_value: actual.actualFinalValue,
    notes: actual.notes,
  });
  if (error) throw error;
}

# ContractorOS Reliable Estimating Core

Assembly-first estimating for plumbing, decking/balustrade, and masonry.

## Run locally

Double-click `Start-Preview.cmd`, or run:

```powershell
npm run build
npm run start -- -p 3010
```

Open `http://127.0.0.1:3010`.

Without Supabase environment values, ContractorOS runs in local data mode and saves data in the browser.

## Supabase and owner login

1. Create a Supabase project.
2. Run `supabase/migrations/001_initial_schema.sql` in the Supabase SQL editor.
3. Create the owner user under Authentication.
4. Copy `.env.example` to `.env.local` and fill in the project URL and anonymous key.

When those values exist, the app requires the Supabase owner login.

## Deploy to Vercel

Import this folder or its GitHub repository into Vercel. Add the same Supabase environment variables, then deploy.

## Data governance

- Trusted records are seeded from the locked plumbing KB, scaling rules, corrected deck benchmark, masonry KB, and commercial rules.
- Saved estimates snapshot their rates and rules.
- CSV imports are reviewed and remain inactive until approved.
- Actual results create review suggestions and never update locked rates automatically.
- Import templates for every governed record type are available under `templates/`.

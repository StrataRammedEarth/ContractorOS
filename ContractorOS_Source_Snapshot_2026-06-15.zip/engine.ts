import type { Assembly, BuyLine, BuildLine, EstimateInput, EstimateLine, EstimateSnapshot, LibraryData } from "./types";

const money = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;

export function calculateEstimate(input: EstimateInput, library: LibraryData, version = 1): EstimateSnapshot {
  const warnings: string[] = [];
  const buyMap = new Map<string, BuyLine>();
  const build: BuildLine[] = [];
  const lines: EstimateLine[] = [];

  for (const scope of input.scope.filter((item) => item.quantity > 0)) {
    const assembly = library.assemblies.find((item) => item.code === scope.assemblyCode && item.status === "Active");
    if (!assembly) {
      warnings.push(`${scope.assemblyCode}: active assembly not found.`);
      continue;
    }
    const factor = scope.quantity / assembly.baseQuantity;
    const lineWarnings: string[] = [];
    let materialTotal = 0;
    let labourTotal = 0;

    for (const recipe of assembly.recipe) {
      const material = library.materials.find((item) => item.code === recipe.materialCode && item.active);
      if (!material || material.unitRate == null) {
        lineWarnings.push(`${recipe.materialCode}: active material price is missing.`);
        continue;
      }
      const quantity = recipe.quantity * factor;
      const total = money(quantity * material.unitRate);
      materialTotal += total;
      const current = buyMap.get(material.code);
      buyMap.set(material.code, {
        materialCode: material.code,
        description: material.description,
        supplier: material.supplier,
        unit: material.unit,
        quantity: money((current?.quantity ?? 0) + quantity),
        unitRate: material.unitRate,
        total: money((current?.total ?? 0) + total),
        confidence: material.confidence,
      });
    }

    for (const labour of assembly.labour) {
      const resource = library.resources.find((item) => item.code === labour.resourceCode);
      if (!resource) {
        lineWarnings.push(`${labour.resourceCode}: labour resource is missing.`);
        continue;
      }
      const quantity = labour.quantity * factor;
      const total = money(quantity * resource.rate);
      labourTotal += total;
      build.push({
        assemblyCode: assembly.code,
        activity: labour.activity,
        resource: resource.name,
        quantity: money(quantity),
        unit: resource.unit,
        rate: resource.rate,
        total,
        confidence: resource.confidence,
      });
    }

    if (assembly.basePrimeCost != null) {
      materialTotal = money((assembly.baseMaterialCost ?? assembly.basePrimeCost) * factor);
      labourTotal = money((assembly.baseLabourCost ?? 0) * factor);
    }

    if (assembly.confidence === "Provisional" || assembly.confidence === "Assumption" || assembly.confidence === "Unknown") {
      lineWarnings.push(`${assembly.code} is ${assembly.confidence.toLowerCase()} grade and requires review.`);
    }
    if (lineWarnings.length) warnings.push(...lineWarnings);

    lines.push({
      code: assembly.code,
      description: assembly.name,
      trade: assembly.trade,
      quantity: scope.quantity,
      unit: assembly.unit,
      material: money(materialTotal),
      labour: money(labourTotal),
      prime: money(materialTotal + labourTotal),
      confidence: assembly.confidence,
      warnings: lineWarnings,
    });
  }

  if (!lines.length) warnings.push("Enter at least one quantity greater than zero before finalising.");

  const material = money(lines.reduce((sum, line) => sum + line.material, 0));
  const labour = money(lines.reduce((sum, line) => sum + line.labour, 0));
  const prime = money(material + labour);
  const waste = money(material * library.rules.wastePct / 100);
  const direct = money(prime + waste);
  const risk = money(direct * library.rules.riskPct / 100);
  const riskAdjusted = money(direct + risk);
  const contingency = money(riskAdjusted * library.rules.contingencyPct / 100);
  const cost = money(riskAdjusted + contingency);
  const margin = money(cost * library.rules.marginPct / 100);
  const sellExVat = money(cost + margin);
  const vat = input.vatEnabled ? money(sellExVat * library.rules.vatPct / 100) : 0;
  const sellIncVat = money(sellExVat + vat);

  return {
    id: crypto.randomUUID(),
    version,
    createdAt: new Date().toISOString(),
    input: structuredClone(input),
    lines,
    buy: [...buyMap.values()].sort((a, b) => a.supplier.localeCompare(b.supplier) || a.description.localeCompare(b.description)),
    build,
    rules: structuredClone(library.rules),
    totals: { material, labour, prime, waste, direct, risk, riskAdjusted, contingency, cost, margin, sellExVat, vat, sellIncVat },
    warnings: [...new Set(warnings)],
  };
}

export function validateForFinal(snapshot: EstimateSnapshot) {
  return {
    valid: snapshot.lines.length > 0 && !snapshot.warnings.some((warning) => warning.includes("missing") || warning.includes("not found")),
    warnings: snapshot.warnings,
  };
}

export function assemblyPrime(assembly: Assembly, quantity: number) {
  return money((assembly.basePrimeCost ?? 0) * quantity / assembly.baseQuantity);
}

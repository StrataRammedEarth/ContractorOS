import Papa from "papaparse";
import type { ImportIssue, Material } from "./types";

const validUnits = new Set(["m", "m2", "m3", "ea", "set", "L", "kg", "roll", "box", "tube", "pack", "pts", "day", "hour"]);

export function reviewMaterialCsv(csv: string, existing: Material[]) {
  const parsed = Papa.parse<Record<string, string>>(csv, { header: true, skipEmptyLines: true });
  const issues: ImportIssue[] = [];
  const accepted: Material[] = [];
  const seen = new Set<string>();

  parsed.data.forEach((row, index) => {
    const code = row.code || row.MaterialCode || row.CostCode || "";
    const description = row.description || row.Description || "";
    const unit = row.unit || row.Unit || "";
    const priceText = row.unitRate || row.UnitRate || row.UnitPrice_ExclVAT || "";
    const price = priceText === "" ? null : Number(priceText);
    const rowNumber = index + 2;

    if (!code || !description) issues.push({ row: rowNumber, severity: "error", code: "conflict", message: "Code and description are required." });
    if (seen.has(code)) issues.push({ row: rowNumber, severity: "error", code: "duplicate", message: `${code} appears more than once in this import.` });
    if (existing.some((item) => item.code === code)) issues.push({ row: rowNumber, severity: "warning", code: "conflict", message: `${code} conflicts with an existing library record and requires approval.` });
    if (!validUnits.has(unit)) issues.push({ row: rowNumber, severity: "error", code: "invalid-unit", message: `${unit || "(blank)"} is not an approved unit.` });
    if (price == null || !Number.isFinite(price)) issues.push({ row: rowNumber, severity: "error", code: "missing-price", message: `${code || "Row"} has no valid active price.` });
    if (/[�]|(?:Ã|â€)/.test(description)) issues.push({ row: rowNumber, severity: "warning", code: "encoding", message: `${code} may contain an encoding problem.` });

    seen.add(code);
    if (code && description && validUnits.has(unit) && price != null && Number.isFinite(price)) {
      accepted.push({
        code, description, unit, unitRate: price,
        supplier: row.supplier || row.SupplierName || "Imported",
        supplierCode: row.SupplierCode,
        confidence: "Unknown",
        source: row.source || row.Source || "CSV import pending approval",
        active: false,
      });
    }
  });

  return { rows: parsed.data.length, accepted, issues, parseErrors: parsed.errors };
}

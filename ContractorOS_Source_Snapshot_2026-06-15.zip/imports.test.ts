import { describe, expect, it } from "vitest";
import { reviewMaterialCsv } from "./imports";
import { materials } from "./seed";

describe("controlled material imports", () => {
  it("reports duplicate, conflict, invalid-unit, and missing-price issues", () => {
    const csv = [
      "code,description,unit,unitRate,supplier",
      "NEW-001,New material,ea,12.50,Supplier",
      "NEW-001,Duplicate material,ea,13.00,Supplier",
      "BE1WH813,Existing material,ea,100,Supplier",
      "BAD-001,Bad unit,thing,10,Supplier",
      "BAD-002,Missing price,ea,,Supplier",
    ].join("\n");
    const result = reviewMaterialCsv(csv, materials);
    for (const code of ["duplicate", "conflict", "invalid-unit", "missing-price"]) {
      expect(result.issues.some((issue) => issue.code === code)).toBe(true);
    }
  });
});
